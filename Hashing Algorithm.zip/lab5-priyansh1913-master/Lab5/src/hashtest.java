import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class hashtest {

    @Test
    void hashPolynomialtesting() {
        hashing hashing=new hashing();
        long hashed=hashing.computePolynomialHash("autoboat",3); // polynomial hash testing
        assertEquals(hashed,338663);
    }

    @Test
    void CompressionMADtesting() {  // MAD collision testing
        hashing hashing=new hashing();
        long hashed=hashing.computeMAD(hashing.computePolynomialHash("autoboat",3),465450,550023,10500,50500);
        assertEquals(hashed,113305);
    }

}
