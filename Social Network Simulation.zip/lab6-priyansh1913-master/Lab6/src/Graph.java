package Lab6.src;

import java.util.*;

public class Graph {
	private final HashMap<Integer, ArrayList<Edge>> adjacencyMap = new HashMap<>();  // creating a hashmap

	public void addVertex(Node node) {   // creating the node
		adjacencyMap.put(node.index, new ArrayList<>());
	}

	public boolean addEdge(Node u, Node v) {  // Here we are adding the edge for two nodes

		Edge edgeUV = new Edge(u.index, v.index);
		Edge edgeVU = new Edge(v.index, u.index);

		if (adjacencyMap.containsKey(u.index) && adjacencyMap.containsKey(v.index)) { // check if both nodes are present in the graph
			adjacencyMap.get(u.index).add(edgeUV);
			adjacencyMap.get(v.index).add(edgeVU);
			return true;  // return true if we can add nodes
		}else{
			return false;  // return false if there are not two nodes we can add
		}
	}

	public boolean areconnected(Node u, Node v) {  // checking if the two created nodes are connected
		if (adjacencyMap.containsKey(u.index) && adjacencyMap.containsKey(v.index)) {  //  Check if there is an edge connecting u to v and an edge connecting v to u
			return hasEdge(u.index, v.index) && hasEdge(v.index, u.index);
		} else {
			return false;  // Return false if one or both nodes are not present
		}
	}

	private boolean hasEdge(int sourceIndex, int targetIndex) {  // check if there is an edge between two nodes
		ArrayList<Edge> edgeList = adjacencyMap.get(sourceIndex);
		String targetEdgeString = sourceIndex + "-" + targetIndex;

		for (Edge edge : edgeList) {  //  Iterate through the list of edges and check if there is a matching edge
			if (edge.toString().equals(targetEdgeString)) {
				return true;   // if matching edge is found
			}
		}

		return false;  // if matching edge is not found
	}
}


