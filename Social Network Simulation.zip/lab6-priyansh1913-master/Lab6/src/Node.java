package Lab6.src;

public class Node {
	int index;

	public Node(int i) {
		index=i;
	}


	boolean areConnected(Node u) {
		//TO DO
		return false;
	}}

