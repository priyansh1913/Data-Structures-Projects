import java.util.Random;

public class Wild {
	static final int MAX_TURNS = 3;
	static  int GRID_SIZE_X = 2;
	static  int GRID_SIZE_Y = 4;
	String[][] animalGrid = new String[GRID_SIZE_X][GRID_SIZE_Y];

	public  Wild() {
		 initializeAnimalGrid();
	}

	public String initializeAnimalGrid() {  // initializing grid
		if (GRID_SIZE_X == 0 || GRID_SIZE_Y == 0) {
			return "Dimensions are zero";
		}
		for (int i = 0; i < GRID_SIZE_X; i++) {
			for (int j = 0; j < GRID_SIZE_Y; j++) {
				animalGrid[i][j] = (new Random().nextInt(2) == 0) ? "deer" : "wolf";
			}
		}
		return "";
	}

	public String simulate() {  // simulate animal interactions
		String[][] newAnimalGrid = new String[GRID_SIZE_X][GRID_SIZE_Y];
		if (!EmptyCells(animalGrid)){
			return "No animals in the area!";
		}else{
		for (int x = 0; x < GRID_SIZE_X; x++) {
			for (int y = 0; y < GRID_SIZE_Y; y++) {
				int neighborX = getRandomNeighborIndex(GRID_SIZE_X);  // random coordinates for a neighboring cell
				int neighborY = getRandomNeighborIndex(GRID_SIZE_Y);
				String currentAnimal = animalGrid[x][y];
				String neighbor = animalGrid[neighborX][neighborY];  // type of animal in current cell and its neighbor

				switch (currentAnimal) {
					case "deer":
						switch (neighbor) {
							case "wolf":
								animalGrid[x][y] = "null";  // if wolf is there deer is eaten
								break;
						}
						break;

					case "wolf":
						switch (neighbor) {
							case "deer":
								animalGrid[neighborX][neighborY] = "wolf";  // if deer is there wolf goes to that location
								animalGrid[x][y] = "null";
								break;
						}
						break;
				}
			}
		}
		return "";
	}}
	private boolean EmptyCells(String[][] array) { // check if there are any animals in the grid
		for (String[] strings : array) {
			for (String string : strings) {
				if (string != null) {
					return true; // if any cell is not null there are animals
				}
			}
		}
		return false;  // no animals are there
	}

	public static void main(String[] args) {
		Wild wildSimulation = new Wild();
		System.out.println("Initial state:");
		wildSimulation.displayAnimalGrid();

		for (int turn = 0; turn < MAX_TURNS; turn++) { // printing generation
			wildSimulation.simulate();
			System.out.println("Generation " + (turn + 1) + ":");
			wildSimulation.displayAnimalGrid();
		}
	}

	public int getRandomNeighborIndex(int size) {  // getting a random neighbor index
		return new Random().nextInt(size);
	}

	public void displayAnimalGrid() {  // method to display the animal grid
		for (String[] row : animalGrid) {
			for (String animal : row) {
				System.out.print(animal + " ");
			}
			System.out.println();
		}
	}
}
