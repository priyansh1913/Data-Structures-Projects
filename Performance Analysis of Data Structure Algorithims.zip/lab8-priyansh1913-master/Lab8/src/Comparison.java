import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Comparison {
    public static void main(String[] args) {
        long startTimeTrie = System.nanoTime();
        Trie.search("ablaze");
        long endTimeTrie = System.nanoTime();
        long trieSearchTime = (endTimeTrie - startTimeTrie) / 1000;
        System.out.println("Trie: " + trieSearchTime + "ps");
        long hashtime = new Comparison().Hashmap();
        System.out.println("Hash: " + hashtime + "ps");
        long avlSearchTime = AVLTree();
        System.out.println("AVL: " + avlSearchTime + "ps");


    }

    public static void Trie() {
        Trie trie = new Trie();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\USER\\Desktop\\lab8-priyansh1913\\Lab8\\src\\words.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                trie.insert(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public long Hashmap() {
        HashMap<String, Boolean> hashMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\USER\\Desktop\\lab8-priyansh1913\\Lab8\\src\\words.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                hashMap.put(line.trim(), true);
            }
        } catch (IOException e) {
            e.printStackTrace();

        }

        long startTimeHash = System.nanoTime();
        boolean word = hashMap.containsKey("AAU");
        long endTimeHash = System.nanoTime();
        long hashSearchTime = (endTimeHash - startTimeHash) / 1000;

        return hashSearchTime;
    }

    public static long AVLTree() {
        AVLTree avl = new AVLTree();
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\USER\\Desktop\\lab8-priyansh1913\\Lab8\\src\\words.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                avl.searchElement(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();



        }
        long startTimeavl = System.nanoTime();
        avl.searchElement("Mexico");
        long endTimeavl = System.nanoTime();
        return (endTimeavl - startTimeavl) / 1000;


    }
}