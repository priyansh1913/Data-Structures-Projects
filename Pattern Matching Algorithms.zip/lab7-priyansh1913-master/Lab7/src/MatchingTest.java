import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MatchingTest {

	@Test
	void testFindKMP() {

		String text = """
                There are numerous benefits of writing unit tests; they help with regression, provide documentation, and facilitate good design. However, hard to read and brittle unit tests can wreak havoc on your code base. This article describes some best practices regarding unit test design for your .NET Core and .NET Standard projects.
                In this guide, you learn some best practices when writing unit tests to keep your tests resilient and easy to understand.
                By John Reese with special thanks to Roy Osherove
                Why unit test?
                There are several reasons to use unit tests.
                Less time performing functional tests
                 Lastly, this process""";


	String pattern = "tests";

	int index = Matching.findKMP(text.toCharArray(), pattern.toCharArray());

		if (index != -1) {
			assertEquals(44, index);
			System.out.println("Kmp Pattern found at index " + index);
		} else {
			System.out.println("Pattern not found in the text");
		}

	// Test if the pattern is found at index 39



		}
	@Test
	void testFindBoyerMoore() {
		String text = """
                There are numerous benefits of writing unit tests; they help with regression, provide documentation, and facilitate good design. However, hard to read and brittle unit tests can wreak havoc on your code base. This article describes some best practices regarding unit test design for your .NET Core and .NET Standard projects.
                In this guide, you learn some best practices when writing unit tests to keep your tests resilient and easy to understand.
                By John Reese with special thanks to Roy Osherove
                Why unit test?
                There are several reasons to use unit tests.
                Less time performing functional tests
                 Lastly, this process""";

		String pattern = "tests";

		int index = Matching.findBoyerMoore(text,pattern);

		if (index != -1) {
			assertEquals(19, index);
			System.out.println("Boyer Moore Pattern found at index " + index);
		} else {
			System.out.println("Pattern not found in the text");
		}


	}

	@Test
	void testFindBrute() {
		String text = """
                There are numerous benefits of writing unit tests; they help with regression, provide documentation, and facilitate good design. However, hard to read and brittle unit tests can wreak havoc on your code base. This article describes some best practices regarding unit test design for your .NET Core and .NET Standard projects.
                In this guide, you learn some best practices when writing unit tests to keep your tests resilient and easy to understand.
                By John Reese with special thanks to Roy Osherove
                Why unit test?
                There are several reasons to use unit tests.
                Less time performing functional tests
                 Lastly, this process""";

		String pattern = "tests";

		int index = Matching.bruteForce(text, pattern);

		if (index != -1) {
			assertEquals(52,index);
			System.out.println("Brute Force Pattern found at index " + index);
		} else {
			System.out.println("Pattern not found in the text");
		}


	}

	@Test
	void testFindRabinKarp() {
		String text = """
                There are numerous benefits of writing unit tests; they help with regression, provide documentation, and facilitate good design. However, hard to read and brittle unit tests can wreak havoc on your code base. This article describes some best practices regarding unit test design for your .NET Core and .NET Standard projects.
                In this guide, you learn some best practices when writing unit tests to keep your tests resilient and easy to understand.
                By John Reese with special thanks to Roy Osherove
                Why unit test?
                There are several reasons to use unit tests.
                Less time performing functional tests
                 Lastly, this process""";

		String pattern = "tests";

		int index = Matching.findRabinKarp(text.toCharArray(), pattern.toCharArray());

		if (index != -1) {
			assertEquals(44,index);
			System.out.println("Rabin Karp Pattern found at index " + index);
		} else {
			System.out.println("Pattern not found in the text");
		}


	}
	}


