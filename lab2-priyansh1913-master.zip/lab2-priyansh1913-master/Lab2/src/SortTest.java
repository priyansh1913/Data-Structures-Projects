import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class SortTest {
    @Test
    void testInsertion1(){
        int[] input= new int[]{1, 5, 7, 2, 6, 8, 3, 4, 9};
        int[] expected= new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9,};
        int[] result= IntSort.InsertionSort(input);

        assertArrayEquals(expected, result);
    }

    @Test
    void testInsertion2(){
        int[] input= new int[]{};
        int[] expected=  new int[]{};
        int[] result= IntSort.InsertionSort(input);

        assertArrayEquals(expected, result);
    }

    @Test
    void testInsertion3(){
        int[] input= new int[]{2, 3, 4, 5, 6};
        int[] expected= new int[]{2, 3, 4, 5, 6};
        int[] result= IntSort.InsertionSort(input);

        assertArrayEquals(expected, result);
    }

    @Test
    void testCounting1(){
        int[] input= new int[] {100000, 50000, 30000, 20000, 10};
        int[] expected= new int[]{10, 20000, 30000, 50000, 100000};
        int[] result= IntSort.CountingSort(input, 100000);

        assertArrayEquals(expected, result);
    }
@Test
    void testCounting2() {
        int[] input = null;
        int[] expected = null;
        int[] result = IntSort.CountingSort(input, 0);

        assertArrayEquals(expected, result);
    }
    @Test

    void testCounting3(){
        int[] input= new int[]{-5,-3,-2,-9,-1};
        assertArrayEquals(IntSort.sort(input),IntSort.CountingSort(input,10));
    }


}
