public class Trie {


    static final int CHAR_SIZE = 256;

    static class TrieNode {
        TrieNode[] children = new TrieNode[CHAR_SIZE];
        boolean isEndOfWord;

        TrieNode() {
            isEndOfWord = false;
            for (int i = 0; i < CHAR_SIZE; i++)
                children[i] = null;
        }
    }

    static TrieNode root;

    static void insert(String key) {
        if (root == null) {
            root = new TrieNode(); // Initialize root if null
        }
        TrieNode pCrawl = root;

        for (int level = 0; level < key.length(); level++) {
            char currentChar = key.charAt(level);
            int index = currentChar;

            if (pCrawl.children[index] == null) {
                pCrawl.children[index] = new TrieNode();
            }

            pCrawl = pCrawl.children[index];
        }

        pCrawl.isEndOfWord = true;

        if (pCrawl != null) {
            pCrawl.isEndOfWord = true;
        }
    }

    static boolean search(String key) {
        TrieNode pCrawl = root;

        for (int level = 0; level < key.length(); level++) {
            char currentChar = key.charAt(level);
            int index = currentChar;

            // Ensure pCrawl is not null and the character exists in the trie
            if (pCrawl == null || pCrawl.children[index] == null) {
                return false;
            }

            pCrawl = pCrawl.children[index];
        }

        // Check if the last node is marked as the end of a word
        return (pCrawl != null && pCrawl.isEndOfWord);
    }


    public static void main(String[] args) {
        root = new TrieNode();

        // Test insertion and search
        insert("apple");
        insert("banana");

        System.out.println(search("apple"));   // Output: true
        System.out.println(search("app"));     // Output: false
        System.out.println(search("banana"));  // Output: true
        System.out.println(search("ban"));     // Output: false
    }
}

