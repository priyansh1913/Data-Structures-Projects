import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

//Write/fix the code as needed to remove warnings/errors and complete the lab 
public class Courses {
	ArrayList<Course> courses = new ArrayList<>();
	
	void loadCourses(){
		courses.add(new Course("COSC","111","Computer Programming I","Introduction to the design, implementation, and understanding of computer programs. Topics include problem solving, algorithm design, and data and procedural abstraction, with emphasis on the development of working programs. This course should be followed by COSC 121.",""));
		courses.add(new Course("COSC","121","Computer Programming II","Advanced programming in the application of software engineering techniques to the design and implementation of programs manipulating complex data structures.","111"));
		courses.add(new Course("COSC","222","Data Structures","database Introduction to the design, implementation and analysis of data structures. Topics will include lists, stacks, queues, trees, and graphs. [3-2-0]\n","121"));
		courses.add(new Course("COSC","211","Machine Architecture","Organization and design of computer systems and their impact on the practice of software development. Instruction set architecture and assembly programming languages, design of central processing units (CPU), memory hierarchy and cache organization, input and output programming.","121"));
	}
	
	public String [] listAll(){
		Course c;
		String []S = new String[courses.size()];
		for (int i=0; i < courses.size(); i++){
			c = (Course) courses.get(i);
			S[i] = (c.accr + " " + c.number + " " + c.title );  // this will print the courses with their acronyms, number and title
		}
		return S;
	}
public void contains(){  //
		courses.stream()
				.filter(course -> course.desc.toLowerCase().contains("database"))
				.forEach(course -> System.out.println(course.accr+ " "+ course.number+ " "+ course.title )); // this checks whether each course and prints the one with the string that has database

}

	public String []listAllIter() {
		String[] s = new String[courses.size()];
		Iterator<Course> iterator = courses.iterator();   // This method does the same thing as listall but with an iterator
         int idx = 0;
		while (iterator.hasNext()) {
			Course c = iterator.next();
			s[idx] = c.getAccr() +  " " + c.getNumber() + " "+ c.getTitle();
			idx++;
		}
		return s;
	}

	public String[] listAllStream() {    // this method uses stream to print each course with their acronyms, number and title
		String[] s =
		courses.stream()
				.map(course -> course.getAccr() + " "+ course.getNumber() + " " + course.getTitle())
				.toArray(sizeofarr -> new String[sizeofarr]);
		return s;
	}

public int howmanycourses(){  // prints the number of courses
	int y = (int)	courses.stream().count();
	return y;
}

	public String displayCourse(String number){  // Displays the courses with their details
		String s = null;
        for (Course c : courses) {
            if (c.getNumber().equals(number)) {
                s = c.getAccr() + " " + c.getNumber() + " " + c.getTitle() + "\n" + c.getDesc() + c.getPrereq();

            }
        }
		return s;
	}

	public void sortcourse(){  // this method sorts the course according to the course number
		courses.stream().sorted(Comparator.comparing(course -> course.number))
				.forEach(course -> System.out.println(course.accr + " " + course.number + " " + course.title));
	}
	
	public static void main(String[] args) {
		Courses L = new Courses();
		L.loadCourses();
		String[] listAll = L.listAll();
        for (String value : listAll) {
            System.out.println(value);
        }

		String[] listAllIter = L.listAllIter();
		for (String string : listAllIter) {
			System.out.println(string);
		}

		System.out.println("\nNumber of Courses: "+ L.howmanycourses());

		System.out.println(L.displayCourse("222"));



		String[] listAllStream = L.listAllStream();
        for (String s : listAllStream) {
            System.out.println(s);
        }


		L.contains();


		L.sortcourse();




	}

}

