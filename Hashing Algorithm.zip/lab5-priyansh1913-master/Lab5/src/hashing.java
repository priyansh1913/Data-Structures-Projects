import java.io.*;
import java.util.*;


public class hashing {

	public HashMap<Long, Long> hashTable = new HashMap<>();   // creating a hashmap
	public HashMap<Long, Long> compressedHashTable = new HashMap<>();


	long computePolynomialHash(String word, int aValue) { // here we compute the hash according to the formula
		long hashing = 0;
		int length = word.length();
		long overflow;

		int i = 0;
		for (char character : word.toCharArray()) {
			length--;
			overflow = hashing;

			if (overflow < 0x7fffffffffffffffL) {
				hashing += character * Math.pow(aValue, length);
			} else {
				hashing += ((long) character * length--);
			}

			i++;
		}

		return hashing;
	}


	long countCollisions(List<String> wordList, int base) {  // counting the number of collisions
		hashTable.clear();
		for (String word : wordList) {
			long hash = computePolynomialHash(word, base);
			hashTable.put(hash, hashTable.getOrDefault(hash, 0L) + 1);
		}
		return hashTable.values().stream().filter(value -> value > 0).count();
	}

	long findMaxCollisions() {
		return Collections.max(hashTable.values());
	}

	long computeMAD(long hash, long N, long p, long alpha, long beta) { // using the multiply divide we compute hash code
		long product = alpha * hash;
		long sum = product + beta;
		long divisionResult = sum % p;
		long modResult = divisionResult % N;
		return modResult;
	}

	long findMaxMADCollisions() {
		return Collections.max(compressedHashTable.values());  // maximum number of collisions
	}
	long countMADCollisions(List<String> wordList, int base, long N, long p, long alpha, long beta) { // computing the number of collisions according to alpha beta and a values
		compressedHashTable.clear();
		for (String word : wordList) {
			long compressedHash = computeMAD(computePolynomialHash(word, base), N, p, alpha, beta);
			compressedHashTable.put(compressedHash, compressedHashTable.getOrDefault(compressedHash, 0L) + 1);
		}
		return compressedHashTable.values().stream().filter(value -> value > 0).count();
	}



	public static void main(String[] args) throws IOException {
		hashing hashing = new hashing();
		List<String> wordList = new ArrayList<>();
		File file = new File("C:\\Users\\USER\\Desktop\\Year 2\\\\\\COSC 222\\word.txt");

		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = bufferedReader.readLine()) != null) {  // reading the text file of the word
				wordList.add(line);
			}
		}



		int[] bases = {10, 33, 37, 39, 41}; // number of bases
		int numBases = bases.length;


		long[][] results = new long[2][numBases];

		for (int i = 0; i < numBases; i++) {
			int base = bases[i];

			results[0][i] = hashing.countCollisions(wordList, base);
			results[1][i] = hashing.findMaxCollisions();
		}


		System.out.print("Base                   ");   // here we print the table
		for (int base : bases) {
			System.out.print(base + "       ");
		}
		System.out.println();

		String[] rowNames = {"Total Collisions   ", "Max Collision      "};  // printing the table
		for (int row = 0; row < 2; row++) {
			System.out.print(rowNames[row] + "    ");
			for (int col = 0; col < numBases; col++) {
				System.out.print(results[row][col] + "   ");
			}
			System.out.println();
		}


		System.out.println("\n After MAD function!");


		long[][] alphaBetaSets = {
				{10000, 50000},
				{100000, 50000},
				{100000, 150000},
				{200000, 150000}
		};

		int base = 48;
		System.out.println(" base is  " + base + "   ");

		for (long[] alphaBeta : alphaBetaSets) {
			long alpha = alphaBeta[0];
			long beta = alphaBeta[1];

			System.out.print(hashing.countMADCollisions(wordList, base, 466550, 560017, 16000, 55000) + "           "); // printing the mad collisions table
			System.out.print(hashing.findMaxMADCollisions());
			System.out.println();
		}


	}


}
