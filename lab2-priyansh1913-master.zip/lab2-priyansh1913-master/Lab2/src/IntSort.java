import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
/**
 * Note that an array of integers are expected
 * 
 * Remember to site sources if you use code from online!
 */
public class IntSort {

	//you may use this to check that your test cases are correct
    public static int[] sort(int[] arr){
    	int[] arrCopy = arr.clone();
        Arrays.sort(arrCopy);
        return arrCopy;
    }



    public static int[] CountingSort(int[] array, int numBuckets) {

        if (array == null || numBuckets <= 0) {
            return array;
        }
        int[] arr = array.clone();

        int max = arr[0];
        int min = arr[0];

        for (int k : arr) {
            if (k > max) {
                max = k;
            }
            if (k < min) {
                min = k;
            }
        }

        if (min == max) {
            return arr;  // here we are checking if max and min are equal
        }


        int range = max - min + 1;
        int[] countArray = new int[range];

        // finding the count occurrences
        for (int j : arr) {
            countArray[j - min]++;
        }

        // creating sorted array
        int index = 0;
        int[] sortedArray = new int[arr.length];
        for (int i = 0; i < range; i++) {
            while (countArray[i] > 0) {
                sortedArray[index] = i + min;
                index++;
                countArray[i]--;
            }
        }

        return sortedArray;
    }

    public static int[] InsertionSort(int[] orgArr){
        //TODO: implement insertion sort as described at https://en.wikipedia.org/wiki/Insertion_sort
        int[] arr = orgArr.clone(); // cloning the array



        for(int i = 1; i<arr.length; i++) { // running the loop to compare the sorted part and unsorted part
            int current= arr[i];
            int j = i-1;
            while(j >= 0 && current<arr[j]) {
                arr[j+1] = arr[j];
                j--;
            }

            arr[j+1]= current;
        }



        return arr; // the array is returned
    }
    //Data structure and sorting algorithms are visualized at https://cmps-people.ok.ubc.ca/ylucet/DS/Algorithms.html
	//in particular see insertion and counting sort

}
