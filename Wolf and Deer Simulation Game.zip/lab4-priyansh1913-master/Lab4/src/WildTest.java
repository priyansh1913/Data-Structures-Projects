import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;

public class WildTest {

    @Test
    public void simulatetest() {
        Wild wilderness = new Wild(); // create a wild instance
        wilderness.initializeAnimalGrid();   // initialize the animal grid
        wilderness.simulate();  // simulate the animal interactions


        boolean move = false;  // check if any animals have moved

        for (int i = 0; i < Wild.GRID_SIZE_X; i++) {
            for (int j = 0; j < Wild.GRID_SIZE_Y; j++) {  // check if the cells are empty
                if (!"".equals(wilderness.animalGrid[i][j])) {
                    move = true;
                    break;
                }
            }
        }
    }

    @Test
    public void initialpoputest() {  // create wild instance
        Wild wilderness = new Wild();
        wilderness.initializeAnimalGrid(); // intialize the grid

        boolean wolf = false;  // intialize the flages to check if wolves and deer is there
        boolean deer = false;

        for (String[] row : wilderness.animalGrid) {  // iterate animal grid
            for (String animal : row) {
                if ("wolf".equals(animal)) {
                    wolf = true;   // check here whether grid contains wolves or deer
                } else if ("deer".equals(animal)) {
                    deer = true;
                }
            }
        }

        assertTrue(wolf);  // checking wolves and deer are presemt
        assertTrue(deer);
    }
    @Test
        public void animalsNull() {
            Wild w = new Wild(); // wild instance
            String expected = "No animals in the area!";  // simulate without intializing the animal grid
            assertEquals(w.simulate(), expected);
        }

    @Test
    public void dimensionzero() {
        Wild w = new Wild();  // create a wild instance
        String expected = "Dimensions are zero";  // simulate with grid dimensions set to zero
        Wild.GRID_SIZE_X = 0;
        Wild.GRID_SIZE_Y = 0;
        assertEquals(w.initializeAnimalGrid(), expected);
    }

    }
