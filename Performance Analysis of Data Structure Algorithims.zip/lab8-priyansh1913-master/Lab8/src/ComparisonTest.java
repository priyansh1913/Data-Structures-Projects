import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;




import java.util.HashMap;


    class ComparisonTest {



        @Test
        void Hashtesting(){
            HashMap<String, Boolean> hashMap = new HashMap<>();
            hashMap.put("mews", true);
            hashMap.put("F1", true);
            hashMap.put("purple", true);

            assertTrue(hashMap.containsKey("mews"));
            assertTrue(hashMap.containsKey("F1"));
            assertFalse(hashMap.containsKey("yellow"));
        }
        @Test
        public void Trietesting(){
            Trie trie = new Trie();
            trie.insert("mews");
            trie.insert("F1");
            trie.insert("purple");

            assertTrue(Trie.search("mews"));
            assertFalse(Trie.search("free"));
            assertFalse(Trie.search("rocks"));
        }
        @Test
        public void avltest(){
            AVLTree avl = new AVLTree();


            avl.insertElement("mews");
            avl.insertElement("F1");
            avl.insertElement("purple");

            assertTrue(avl.searchElement("mews"));
            assertFalse(avl.searchElement("free"));
            assertFalse(avl.searchElement("rocks"));
        }
        }


