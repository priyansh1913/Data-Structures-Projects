//The code below is taken from the website: https://www.javatpoint.com/avl-tree-program-in-java

class Node {
    String element;
    int h;  // for height
    Node leftChild;
    Node rightChild;

    // default constructor to create a null node
    public Node() {
        leftChild = null;
        rightChild = null;
        element = null;
        h = 0;
    }

    // parameterized constructor
    public Node(String element) {
        leftChild = null;
        rightChild = null;
        this.element = element;
        h = 0;
    }
}

// for constructing AVL Tree
public class AVLTree {
    private Node rootNode;

    // Constructor to set null value to the rootNode
    public AVLTree() {
        rootNode = null;
    }

    // create insertElement() to insert an element into the AVL Tree
    public void insertElement(String element) {
        rootNode = insertElement(element, rootNode);
    }

    // create insertElement() method to insert data into the AVL Tree recursively
    private Node insertElement(String element, Node node) {
        // check whether the node is null or not
        if (node == null)
            node = new Node(element);
            // insert a node in case when the given element is lesser than the element of the root node
        else if (element.compareTo(node.element) < 0) {
            node.leftChild = insertElement(element, node.leftChild);
            if (getHeight(node.leftChild) - getHeight(node.rightChild) == 2)
                if (element.compareTo(node.leftChild.element) < 0)
                    node = rotateWithLeftChild(node);
                else
                    node = doubleWithLeftChild(node);
        } else if (element.compareTo(node.element) > 0) {
            node.rightChild = insertElement(element, node.rightChild);
            if (getHeight(node.rightChild) - getHeight(node.leftChild) == 2)
                if (element.compareTo(node.rightChild.element) > 0)
                    node = rotateWithRightChild(node);
                else
                    node = doubleWithRightChild(node);
        } else
            ;  // if the element is already present in the tree, we will do nothing
        node.h = getMaxHeight(getHeight(node.leftChild), getHeight(node.rightChild)) + 1;

        return node;
    }

    // creating rotateWithLeftChild() method to perform rotation of binary tree node with left child
    private Node rotateWithLeftChild(Node node2) {
        Node node1 = node2.leftChild;
        node2.leftChild = node1.rightChild;
        node1.rightChild = node2;
        node2.h = getMaxHeight(getHeight(node2.leftChild), getHeight(node2.rightChild)) + 1;
        node1.h = getMaxHeight(getHeight(node1.leftChild), node2.h) + 1;
        return node1;
    }

    private Node rotateWithRightChild(Node node1) {
        Node node2 = node1.rightChild;
        node1.rightChild = node2.leftChild;
        node2.leftChild = node1;
        node1.h = getMaxHeight(getHeight(node1.leftChild), getHeight(node1.rightChild)) + 1;
        node2.h = getMaxHeight(getHeight(node2.rightChild), node1.h) + 1;
        return node2;
    }

    private int getHeight(Node node) {
        return node == null ? -1 : node.h;
    }

    private int getMaxHeight(int leftNodeHeight, int rightNodeHeight) {
        return Math.max(leftNodeHeight, rightNodeHeight);
    }

    private Node doubleWithLeftChild(Node node3) {
        node3.leftChild = rotateWithRightChild(node3.leftChild);
        return rotateWithLeftChild(node3);
    }


    private Node doubleWithRightChild(Node node1) {
        node1.rightChild = rotateWithLeftChild(node1.rightChild);
        return rotateWithRightChild(node1);
    }



    public boolean searchElement(String element) {
        return searchElement(rootNode, element);
    }

    private boolean searchElement(Node head, String element) {
        boolean check = false;
        while ((head != null) && !check) {
            int comparison = element.compareTo(head.element);
            if (comparison < 0)
                head = head.leftChild;
            else if (comparison > 0)
                head = head.rightChild;
            else {
                check = true;
                break;
            }
            check = searchElement(head, element);
        }
        return check;
    }
}
