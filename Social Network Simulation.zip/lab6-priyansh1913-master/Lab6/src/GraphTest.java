package Lab6.src;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GraphTest {

	@Test
	void testIsConnected() {

		Node n =new Node(4); // creating a new node
		Node n1 =new Node(5);  // creating another new node
		Graph graph=new Graph();  // initiating the graph
		graph.addVertex(n1);
		graph.addVertex(n);  // Adding both nodes to the graph as vertices
        graph.addEdge(n, n1);  // Adding an edge between nodes n and n1
		assertTrue(graph.areconnected(n, n1));  // checking that nodes n and n1 are connected in the graph



	}

}
