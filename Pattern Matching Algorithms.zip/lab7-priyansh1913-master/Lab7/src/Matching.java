import java.util.Arrays;

public class Matching {

	private static final int NO_OF_CHARS = 256;

	public static int findKMP(char[] text, char[] pattern) {
		int comparisons = 0;
		int n = text.length;
		int m = pattern.length;

		int[] lps = new int[m];
		int len = 0;
		int i = 1;

		while (i < m) {
			comparisons++;
			if (pattern[i] == pattern[len]) {
				len++;
				lps[i] = len;
				i++;
			} else {
				if (len != 0) {
					len = lps[len - 1];
				} else {
					lps[i] = len;
					i++;
				}
			}
		}

		int j = 0;
		i = 0;
		while (i < n) {
			comparisons++;
			if (pattern[j] == text[i]) {
				i++;
				j++;
			}

			if (j == m) {
				return i - j; // Pattern found then we return to the starting index
			} else if (i < n && pattern[j] != text[i]) {
				if (j != 0) {
					j = lps[j - 1];
				} else {
					i++;
				}
			}
		}

		return -1; // Pattern not found at this index
	}





	public static int findBoyerMoore(String text, String pattern) {
		int c = text.length();
		int d = pattern.length();
		int comparisons = 0;

		int[] badCharacter = new int[256];
		Arrays.fill(badCharacter, -1);

		for (int i = 0; i < d; i++) {
			badCharacter[pattern.charAt(i)] = i;
		}

		int i = 0;
		while (i <= c - d) {
			int j = d - 1;
			while (j >= 0) {
				comparisons++;
				if (text.charAt(i + j) != pattern.charAt(j)) {
					int badCharShift = badCharacter[text.charAt(i + j)];
					i += Math.max(1, j - badCharShift);
					break;
				}
				j--;
			}

			if (j < 0) {
				// Pattern found
				return comparisons;
			}
		}

		return -1;
	}




	public static int bruteForce(String text, String pattern) {
		int comparisons = 0;
		int a = text.length();
		int b = pattern.length();

		int i = 0;
		while (i <= a - b) {
			int j = 0;
			while (j < b) {
				comparisons++;
				if (text.charAt(i + j) != pattern.charAt(j)) {
					break;
				}
				j++;
			}
			if (j == b) {
				return comparisons;
			}
			i++;
		}

		return -1;
	}


	public static int findRabinKarp(char[] text, char[] pattern) {
		final int d = 256;
		int n = text.length;
		int m = pattern.length;
		int q = 131; // A odd prime number

		int h = 1;
		for (int i = 0; i < m - 1; i++) {
			h = (h * d) % q;
		}

		int p = 0; // Hash value for pattern
		int t = 0; // Hash value for text
		int i, j;

		for (i = 0; i < m; i++) {
			p = (d * p + pattern[i]) % q;
			t = (d * t + text[i]) % q;
		}

		i = 0;
		while (i <= n - m) {
			if (p == t) {
				for (j = 0; j < m; j++) {
					if (text[i + j] != pattern[j]) {
						break;
					}
				}
				if (j == m) {
					return i; // Pattern found at index i
				}
			}
			if (i < n - m) {
				t = (d * (t - text[i] * h) + text[i + m]) % q;
				if (t < 0) {
					t = (t + q);
				}
			}
			i++;
		}
		return -1; // The Pattern is not found in text
	}
}
