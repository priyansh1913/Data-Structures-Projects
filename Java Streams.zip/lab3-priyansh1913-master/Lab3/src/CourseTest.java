import org.junit.jupiter.api.Test;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;


public class CourseTest {
    @Test
    void testA(){
        Courses courses= new Courses();
        courses.loadCourses();

        String[] listAllStream= courses.listAllStream();
        String[] listAllIter= courses.listAllIter();

        String[] listAll= courses.listAll();

        assertArrayEquals(listAll, listAllStream);
        assertArrayEquals(listAll, listAllIter);

    }
}
